<?php 
include DOSSIER_VIEWS . '/parties/header.html.php';
include DOSSIER_VIEWS . '/parties/footer.html.php';
?>