<?php

class Contact extends SimpleOrm {
	public $id;
	public $nom;
	public $prenom;
	public $telephone;
}
