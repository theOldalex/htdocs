<?php


function erreur500() {
	redirection('500');
}

function erreur404() {
	redirection('404');
}

function erreur403() {
	redirection('403');
}

function url(string $route): string {
	return BASE_URL . '/index.php?route=' . $route;
}

/**
 * Voir la doc de la fonction `header`
 * https://www.php.net/manual/fr/function.header.php
 */
function redirection(string $route) {
	header('location: ' . url($route));
	die();
}

function view(string $nom): string {
	return DOSSIER_VIEWS . '/' . $nom . '.php';
}

function is_admin(): bool {
	return is_connected() && $_SESSION['pseudo'] == 'admin';
}

function is_connected(): bool {
	return !empty($_SESSION['pseudo']) && !empty($_SESSION['id']);
}

function reconnecter_utilisateur_par_cookie() {
	/**
	 * Check les cookies
	 */
	if (!is_connected()) {
		if (!empty($_COOKIE['token'])) {
			require DOSSIER_MODELS . '/Utilisateur.php';
			$utilisateur = Utilisateur::retrieveByField('token', $_COOKIE['token'], SimpleOrm::FETCH_ONE);

			if ($utilisateur !== null) {
				$_SESSION['pseudo'] = $utilisateur->pseudo;
				$_SESSION['id'] = $utilisateur->id;

				creer_cookie_token($utilisateur);
			}
		}
	}
}


function creer_cookie_token($utilisateur) {
	/**
	 * On crée une chaîne de caractères aléatoires
	 * Donc pas prédictible
	 * Donc difficile à voler
	 */
	$utilisateur->token = hash('sha256', random_bytes(32));
	$utilisateur->save();


	/**
	 * Je crée un cookie
	 * Doc de setcookie : https://www.php.net/manual/fr/function.setcookie.php
	 * 
	 * Je stocke le token dedans
	 */
	setcookie(
		'token', // Le nom du cookie (on récupèrera un $_COOKIE['pseudo'])
		$utilisateur->token, // La valeur du cookie
		time() + 365 * 24 * 3600 // La date d'expiration (un timestamp) dans un an
	);
}
