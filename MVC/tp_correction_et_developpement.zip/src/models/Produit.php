<?php

class Produit extends SimpleOrm {
	public $id;
	public $nom;
	public $image;
	public $prix;
	public $stock;
	public $description;
}
