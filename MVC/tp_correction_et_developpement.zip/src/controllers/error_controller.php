<?php

function page403() {
	include view('errors/403');
}

function page404() {
	include view('errors/404');
}

function page500() {
	include view('errors/500');
}