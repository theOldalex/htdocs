<?php

function afficher_accueil() {
	$titre = 'Accueil';
	include view('home');
}