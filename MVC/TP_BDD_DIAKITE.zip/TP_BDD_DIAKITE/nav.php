<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


<div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">TP Alexandre Diakité</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="home.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="liste-produits-model.php">Liste-produits</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Détails-produit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Ajouter-produit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Supprimer-produit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Connexion</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
