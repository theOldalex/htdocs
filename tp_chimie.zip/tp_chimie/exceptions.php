<?php


class NotFoundException extends Exception {}

class ServerErrorException extends Exception {}

class AccessDeniedException extends Exception {}