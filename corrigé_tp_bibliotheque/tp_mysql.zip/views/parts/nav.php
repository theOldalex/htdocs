<nav class="nav justify-content-center">
	<a class="nav-link" href="<?= url('liste-livres') ?>">Liste des livres</a>
	<a class="nav-link" href="<?= url('ajouter-livre') ?>">Ajouter un livre</a>
	<a class="nav-link" href="<?= url('liste-emprunts') ?>">Liste des emprunts</a>
	<a class="nav-link" href="<?= url('ajouter-emprunt') ?>">Ajouter un emprunt</a>
</nav>