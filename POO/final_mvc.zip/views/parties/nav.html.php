<nav class="nav justify-content-center">
	<a class="nav-link" href="<?= Helper::url('home') ?>">Accueil</a>
	<a class="nav-link" href="<?= Helper::url('liste-livres') ?>">Les livres</a>
</nav>