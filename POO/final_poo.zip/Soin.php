<?php

/**
 * Créez une classe PHP qui représente un soin (générique)
 * 
 * Un soin est défini par le nombre de points de vie qu'il peut rendre en une seul utilisation
 * 
 * La seule action de cette classe est statique : soigner un personnage
 * Un soin rend des points de vie (d'un montant défini dans la classe) à un personnage
 * 
 * Créez 3 soins distincts
 */
class Soin {
    const PV_RENDUS = 10;

    public static function soigner(Personnage $quelqu_un) {
        $quelqu_un->etreSoigne(static::PV_RENDUS);
    }
}

class Potion extends Soin {
    const PV_RENDUS = 25;
}

class BatonDeSoin extends Soin {
    const PV_RENDUS = 50;
}

