<?php

/**
 * Définissez la classe Archer, qui est un genre de Personnage
 */
require_once __DIR__ . '/Personnage.php';

class Archer extends Personnage {
	public $nbFleches;

	public function __construct(string $pseudo, int $nbFleches, int $age) {
		$this->nbFleches = $nbFleches;
		parent::__construct($pseudo, 10, $age, 50);
	}

	public function tirerUneFleche(Personnage $quelqu_un) {
		if ($this->nbFleches > 0) {
			$degats = 150;
			$this->nbFleches--;
			$this->parler($this->pseudo . ' tire sur ' . $quelqu_un->pseudo . '.');
			$quelqu_un->prendreDesDegats($degats);
		} else {
			$this->parler('Le carquois de ' . $this->pseudo . ' est vide...');
		}
	}
}
