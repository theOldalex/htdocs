<?php

/**
 * Créez une classe narrateur, qui n'aura qu'une méthode statique : parler
 * 
 * (Personnalisez la méthode pour personnaliser votre affichage ;-))
 */
require_once './Personnage.php';

class Narrateur {
    public static function parler(string $parole, Personnage $quelqu_un = null): void {
        echo '<div class="card">';
        if (!empty($quelqu_un)) echo $quelqu_un->pseudo . '&nbsp;: ';

        echo $parole;
        echo '</div>' . PHP_EOL;
    }
}
