<?php

/**
 * Définissez la classe Mage, qui est un genre de Personnage
 */
require_once __DIR__ . '/Personnage.php';

class Mage extends Personnage {
	protected $mana; // On n'autorise pas l'accès externe au mana
	protected $forceMagique;

	public function __construct(string $pseudo, int $forceMagique, int $age, int $mana = 100) {
		$this->forceMagique = $forceMagique;
		$this->mana = $mana;
		parent::__construct($pseudo, 80, $age, 200);
	}

	public function envoyerUnSort(Personnage $quelqu_un) {
		if ($this->dansLaMemeGuilde($quelqu_un)) {
			$this->parler('On tape pas les copains !');
			return;
		}

		if (!$this->estMort() && $this->mana >= 20) {
			$this->parler($this->pseudo . ' envoie un sort sur ' . $quelqu_un->pseudo . '.');

			$degats = $this->forceMagique + $this->age / 10;
			$this->mana -= 20;
			$quelqu_un->prendreDesDegats($degats);
		}
	}

	/**
	 * Accesseur du mana
	 */
	public function getMana() {
		return $this->mana;
	}

	/**
	 * Mutateur du mana
	 */
	public function perdreMana(int $combien) {
		$this->mana -= $combien;
	}
}
