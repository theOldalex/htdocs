<?php

require_once __DIR__ . '/Cheval.php';
require_once __DIR__ . '/Guilde.php';
require_once __DIR__ . '/Archer.php';
require_once __DIR__ . '/Paladin.php';
require_once __DIR__ . '/Mage.php';
require_once __DIR__ . '/Soin.php';
require_once __DIR__ . '/Arme.php';
require_once __DIR__ . '/Narrateur.php';
require_once __DIR__ . '/Monture.php';


$findus = new Cheval('Findus', 35, 5);

$findus->galoper();
$findus->galoper();

$findus->seReposer();


$merlin = new Mage('Merlin', 150, 200);
$batman = new Paladin('Batman', 200, 35);
$joker = new Archer('Le Joker', 15,  35);

$guilde = new Guilde;
$guilde->nom = 'La ligue des ombres';
$guilde->accueillir($merlin);
$guilde->accueillir($batman);


$batman->chevaucher($findus);

$batman->frapper($merlin);
$batman->frapper($joker);


$guillaume_tell = new Archer('Guillaume Tell', 15, 25);
$guillaume_tell->tirerUneFleche($batman);

$lancelot = new Paladin('Lancelot', 50, 35);
$joker->bouleDeFeu($lancelot);

$merlin->parler('Je soigne Lancelot !');
BatonDeSoin::soigner($lancelot);
$merlin->parler('Je soigne Guillaume !');
Potion::soigner($guillaume_tell);

$lancelot->frapper($joker);
$lancelot->bouleDeFeu($merlin);

$gandalf = new Mage('Gandalf', 300, 7000, 200);

$merlin->envoyerUnSort($lancelot);

$merlin->parler('Je m\'en vais pourfendre ce grand gris !');
Epee::frapper($gandalf);

$gandalf->envoyerUnSort($merlin);

$gandalf->chevaucher($merlin);

$dumbo = new ElephantDeGuerre;

$batman->chevaucher($dumbo);
