<?php

/**
 * Définissez une classe abstraite qui représente une monture.
 * 
 * Une monture est définie par des points de vie, une endurance et une vitesse.
 * Une monture est chevauchable.
 * 
 * Faites en sorte que le Cheval (cf. partie 1) soit une monture.
 * Créez deux autres montures.
 */

require_once './Chevauchable.php';

abstract class Monture implements Chevauchable {
    public $pv;
    public $nom;
    public $endurance;
    public $vitesse;

    public function prendreLaFuite() {
        Narrateur::parler($this->nom . ' prend la fuite en abandonnant son cavalier (le lâche).');
    }

    /**
     * Puisqu'on implémente Chevauchable
     * 
     * On a automatiquement "hérité" d'une méthode abstraite
     * abstract public function etreChevauche(Personnage $quelqu_un);
     */
}

class Licorne extends Monture {
    public function etreChevauche(Personnage $quelqu_un) {
        Narrateur::parler('J\'aime les licornes et leur jolie corne.');
        $quelqu_un->parler('Ca fait des arcs-en-ciel !');
    }
}

class ElephantDeGuerre extends Monture {
    public function etreChevauche(Personnage $quelqu_un) {
        if (rand(1, 100) < 5) {
            $quelqu_un->parler('Ca tangue trop, ça me fait mal !');
            $quelqu_un->prendreDesDegats(5);
        } else {
            $quelqu_un->parler('Tremblez devant ma machine de guerre !');
        }
    }
}
