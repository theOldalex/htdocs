<?php

/**
 * Créez une classe PHP qui représente une arme (générique)
 * 
 * Une arme est définie par les dégats qu'elle peut infliger
 * 
 * La seule action de cette classe est statique : attaquer un personnage
 * Une attaque inflige le montant de dégats (défini dans la classe) à un personnage
 * 
 * Créez 3 armes distinctes
 */
class Arme {
    const DEGATS = 10;

    public static function frapper(Personnage $quelqu_un) {
        $quelqu_un->prendreDesDegats(static::DEGATS);
    }
}

class Epee extends Arme {
    const DEGATS = 25;
}

class Lance extends Arme {
    const DEGATS = 50;
}
