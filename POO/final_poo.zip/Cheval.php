<?php

/**
 * La classe PHP qui représente un cheval
 * 
 * Un cheval est caractérisé par sa vitesse et son endurance
 * Les actions d'un cheval se résument à :
 * 		- Galoper
 * 		- Prendre la fuite (les lâches)
 *      - Chevaucher
 */
require_once __DIR__ . '/Personnage.php';
require_once './Narrateur.php';
require_once './Monture.php';

class Cheval extends Monture {
	public function __construct(string $nom, int $vitesse = 25, $endurance = 100) {
		$this->nom = $nom;
		$this->vitesse = $vitesse;
		$this->endurance = $endurance;
	}

	public function galoper() {
		if ($this->endurance > 0) {
			$this->endurance -= 5;
			Narrateur::parler($this->nom . ' galope à ' . $this->vitesse . ' km/h.');
		} else {
			Narrateur::parler($this->nom . ' ne peut pas galoper car il est épuisé.');
		}
	}

	public function etreChevauche(Personnage $quelqu_un) {
		if ($this->endurance > 0) {
			$this->endurance -= 5;
			Narrateur::parler($this->nom . ' chevauche avec son cavalier ' . $quelqu_un->pseudo . '.');
		} else {
			Narrateur::parler($this->nom . ' ne peut pas chevaucher car il est épuisé.');
		}
	}

	public function seReposer() {
		Narrateur::parler($this->nom . ' se repose.');
		$this->endurance += 10;

		if ($this->endurance > 100) $this->endurance = 100;
	}
}
