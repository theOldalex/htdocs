<?php

/**
 * Définissez la classe Paladin, qui est un genre de Personnage
 */
require_once __DIR__ . '/Personnage.php';

class Paladin extends Personnage {
	public $pointsBouclier;

	/**
	 * Le constructeur est une exception à la règle
	 * de la compatibilité des méthodes
	 */
	public function __construct(string $pseudo, int $pointsBoucliers, int $age) {
		$this->pointsBouclier = $pointsBoucliers;
		parent::__construct($pseudo, 120, $age, 300);
	}

	/**
	 * La forme des méthodes héritées 
	 * doit être "compatible" avec la méthode parent
	 * 
	 * (nombre d'arguments, nom de la méthode, type de retour)
	 */
	public function prendreDesDegats(int $combien, bool $parade = false) {
		if ($parade) {
			/**
			 * Le bouclier va absorber 50 % des degats (maximum)
			 */
			$degats_sur_bouclier = min(ceil($combien / 2), $this->pointsBouclier);
			$vrais_degats = $combien - $degats_sur_bouclier;

			$this->pointsBouclier -= $degats_sur_bouclier;

			$this->parler('Le bouclier de ' . $this->pseudo . ' absorbe ' . $degats_sur_bouclier . ' dégats.');

			if ($this->pointsBouclier <= 0) $this->parler('Le bouclier de ' . $this->pseudo . ' se brise.');
		} else $vrais_degats = $combien;

		parent::prendreDesDegats($vrais_degats);
	}
}
