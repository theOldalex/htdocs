<?php

/**
 * Définissez le "contrat" Chevauchable, 
 * qui stipule qu'une classe qui l'implémente doit implémenter la méthode chevaucher()
 * 
 * Implémentez ce contrat sur la classe Cheval (cf. partie 1)
 */
require_once './Personnage.php';

interface Chevauchable {
    public function etreChevauche(Personnage $quelqu_un);
    public function prendreLaFuite();
}
