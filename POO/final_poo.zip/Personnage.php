<?php

/**
 * Créez une classe PHP qui représente un personnage de jeu vidéo (type RPG)
 * Un personnage est caractérisé par un pseudo, des points de vie, sa force 
 * (ainsi que tous les points de caractéristique que vous voudrez)
 * 
 * Les actions d'un personnage consistent en : 
 * 		- Frapper (infliger des dégats à un autre personnage en fonction de sa force)
 * 		- Chevaucher un Cheval (ce qui appelle la méthode chevauche de la classe Cheval)
 */
require_once __DIR__ . '/Cheval.php';
require_once __DIR__ . '/Narrateur.php';
require_once __DIR__ . '/Chevauchable.php';

class Personnage implements Chevauchable {
	public $pseudo;
	protected $pv; // On n'autorise pas l'accès externe aux PV
	public $force;
	public $age;
	public $guilde;

	public function __construct(string $pseudo, int $force, int $age, int $pv = 100) {
		$this->pseudo = $pseudo;
		$this->pv = $pv;
		$this->force = $force;
		$this->age = $age;
	}

	public function frapper(Personnage $quelqu_un) {

		if ($this->dansLaMemeGuilde($quelqu_un)) {
			$this->parler('On tape pas les copains !');
			return;
		}

		if (!$this->estMort()) {
			$this->parler($this->pseudo . ' frappe ' . $quelqu_un->pseudo);
			// if ($this->pseudo == 'Chuck Norris') unset($quelqu_un);

			$degats = $this->force - $this->age;
			$quelqu_un->prendreDesDegats($degats);
		}
	}

	public function bouleDeFeu(Personnage $quelqu_un) {
		if ($this->dansLaMemeGuilde($quelqu_un)) {
			$this->parler('On tape pas les copains !');
			return;
		}

		if (!$this->estMort()) {
			$this->parler($this->pseudo . ' envoie une boule de feu sur ' . $quelqu_un->pseudo . '.');

			/**
			 * Si le Personnage $quelqu_un est un Mage
			 * Alors il absorbe la boule de feu
			 * Au prix de 10 points de mana
			 */
			if ($quelqu_un instanceof Mage && $quelqu_un->getMana() > 10) {
				$quelqu_un->perdreMana(10);
				$this->parler($quelqu_un->pseudo . ' absorbe le sort.');
			} else {
				$degats = $this->force - $this->age;
				$quelqu_un->prendreDesDegats($degats);
			}
		}
	}

	public function prendreDesDegats(int $combien) {
		$de = rand(1, 100); // Un dé 100
		if ($de < 10) $this->parler($this->pseudo . ' évite les dégats en esquivant.');
		else {
			$this->parler($this->pseudo . ' perd ' . $combien . ' PV.');
			$this->pv -= $combien;

			if ($this->estMort()) $this->parler($this->pseudo . ' est mort. RIP.');
			elseif ($this->pv == 1) $this->prendreLaFuite();
		}
	}

	public function etreSoigne(int $combien) {
		$this->parler('Je prends un soin et suis soigné de ' . $combien . ' PV.');
		$this->pv += $combien;
	}

	public function chevaucher(Chevauchable $canasson) {
		if (rand(0, 1)) $canasson->prendreLaFuite();
		else $canasson->etreChevauche($this);
	}

	public function etreChevauche(Personnage $quelqu_un) {
		$quelqu_un->parler('T\'aimes ça, hein, que je te chevauche, petit saligot de ' . $this->pseudo . ' ?');
	}

	public function prendreLaFuite() {
		$this->parler('Maman, au secours !');
	}

	public function estMort() {
		if ($this->pv > 0) return false;
		else return true;
	}

	public function dansLaMemeGuilde(Personnage $quelqu_un) {
		if (!empty($this->guilde) && $quelqu_un->guilde == $this->guilde) return true;
		else return false;
	}

	public function parler(string $parole) {
		Narrateur::parler($parole, $this);
	}
}
